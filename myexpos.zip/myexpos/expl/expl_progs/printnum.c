#include<stdio.h>

int main(){
	for(int i=0;i<=2047;i++)
		printf("%d\n",i);
	return 0;
}
